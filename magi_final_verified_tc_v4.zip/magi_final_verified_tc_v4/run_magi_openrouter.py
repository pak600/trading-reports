import asyncio
import os
import sys
from magi import MAGI

async def main():
    # ==========================================
    # 在這裡直接填入您的 OpenRouter API Key
    # ==========================================
    # os.environ["OPENROUTER_API_KEY"] = "sk-or-v1-..." 
    
    # 檢查環境變數是否已設定 (無論是手動填寫或外部 export)
    api_key = os.environ.get("OPENROUTER_API_KEY")
    if not api_key or api_key == "sk-or-your-key-here":
        print("錯誤: 請先設定環境變數 OPENROUTER_API_KEY")
        print("您可以在此腳本的第 10 行直接填寫，或在 .env 檔案中填寫。")
        return

    # 使用修改後的預設模型 (StepFun / NVIDIA / MiniMax)
    engine = MAGI()

    query = "請分析 Rust 與 Go 在後端開發中的優缺點，並給出建議。"
    if len(sys.argv) > 1:
        query = sys.argv[1]

    print(f"正在詢問 MAGI (模式: adaptive): {query}\n")
    print("正在啟動三個免費節點進行決策 (StepFun / NVIDIA / MiniMax)...\n")

    try:
        decision = await engine.ask(query, mode="adaptive")

        print("-" * 50)
        print(f"最終裁決 (Ruling):\n{decision.ruling}\n")
        print("-" * 50)
        print(f"信心度 (Confidence): {decision.confidence:.2%}")
        print(f"使用的協議 (Protocol): {decision.protocol_used}")
        
        if decision.minority_report:
            print("\n少數報告 (Minority Report):")
            print(decision.minority_report)
            
        if decision.mind_changes:
            print(f"\n立場改變的節點: {', '.join(decision.mind_changes)}")
            
        print(f"\n延遲時間: {decision.latency_ms} ms")
        
    except Exception as e:
        print(f"執行出錯: {e}")

if __name__ == "__main__":
    asyncio.run(main())
