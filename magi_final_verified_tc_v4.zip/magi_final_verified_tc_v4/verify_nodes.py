import asyncio
import os
import sys
from pathlib import Path
from dotenv import load_dotenv
from magi.core.node import MagiNode, Persona

# 1. 載入環境變數
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

async def test_node(node_name, model_id, persona_desc):
    print(f"\n[測試] 正在連線至 {node_name.upper()} (模型: {model_id})...")
    
    persona = Persona(node_name.capitalize(), persona_desc)
    node = MagiNode(node_name, model_id, persona, timeout=60)
    
    try:
        # 發送一個簡單的問題進行測試
        response = await node.query("你好，請用一句話介紹你自己。")
        print(f"[成功] {node_name.upper()} 回傳內容：\n      \"{response}\"")
        return True
    except Exception as e:
        print(f"[失敗] {node_name.upper()} 發生錯誤：{str(e)[:200]}")
        return False

async def main():
    api_key = os.environ.get("OPENROUTER_API_KEY")
    if not api_key or api_key == "sk-or-your-key-here":
        print("錯誤：請先在 .env 檔案中填入您的 OPENROUTER_API_KEY")
        return

    print("==========================================")
    print("   MAGI 三台電腦連線測試工具 (OpenRouter)")
    print("==========================================")
    
    # 讀取 .env 中的模型設定，若無則使用預設值
    models = {
        "melchior": os.environ.get("MAGI_MELCHIOR", "openrouter/stepfun/step-3-5-flash"),
        "balthasar": os.environ.get("MAGI_BALTHASAR", "openrouter/nvidia/nemotron-3-super"),
        "casper": os.environ.get("MAGI_CASPER", "openrouter/minimax/minimax-m2-5")
    }
    
    personas = {
        "melchior": "科學家視角，注重邏輯。",
        "balthasar": "母親視角，注重倫理。",
        "casper": "領導者視角，注重務實。"
    }

    tasks = [
        test_node("melchior", models["melchior"], personas["melchior"]),
        test_node("balthasar", models["balthasar"], personas["balthasar"]),
        test_node("casper", models["casper"], personas["casper"])
    ]
    
    results = await asyncio.gather(*tasks)
    
    print("\n" + "="*42)
    if all(results):
        print("   所有電腦均已連線成功！您可以啟動網頁介面了。")
    else:
        print("   部分電腦連線失敗，請檢查 API Key 或模型 ID。")
    print("="*42)

if __name__ == "__main__":
    asyncio.run(main())
