@echo off
setlocal enabledelayedexpansion

echo ==========================================
echo   MAGI NERV Command Center - One-Click
echo ==========================================

:: Check for .env file
if not exist .env (
    echo [ERROR] .env file not found. Please create one based on .env.example.
    pause
    exit /b
)

:: Load environment variables from .env
for /f "tokens=*" %%a in ('type .env ^| findstr /v "^#"') do (
    set "%%a"
)

:: Install dependencies
echo [INFO] Checking dependencies...
pip install fastapi uvicorn websockets python-dotenv litellm -q

:: Start MAGI Dashboard on port 3001
echo [INFO] Starting NERV Command Center at http://localhost:3001
echo [INFO] Do not close this window while using the dashboard.

:: Open browser
start http://localhost:3001

:: Run MAGI Dashboard with explicit port 3001
magi dashboard --port 3001

pause
