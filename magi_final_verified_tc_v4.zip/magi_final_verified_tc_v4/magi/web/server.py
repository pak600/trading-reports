"""MAGI NERV Command Center — WebSocket server for real-time decision visualization."""
import asyncio
import json
import time
import os
import logging
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from magi.core.engine import MAGI
from magi.core.node import MagiNode, Persona
from magi.core.decision import Decision
from magi.presets import get_preset, list_presets
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("magi.server")

# Force load .env from project root
load_dotenv(Path(__file__).parent.parent.parent / ".env")

app = FastAPI(title="MAGI NERV Command Center")

STATIC_DIR = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/")
async def index():
    return FileResponse(str(STATIC_DIR / "index.html"))


@app.get("/api/defaults")
async def api_defaults():
    # Use the optimized model IDs from engine.py as fallback
    return {
        "melchior": os.environ.get("MAGI_MELCHIOR", "openrouter/nvidia/nemotron-3-super-120b-a12b:free"),
        "balthasar": os.environ.get("MAGI_BALTHASAR", "openrouter/stepfun/step-3-5-flash:free"),
        "casper": os.environ.get("MAGI_CASPER", "openrouter/meta-llama/llama-3.2-3b-instruct:free"),
    }


@app.websocket("/ws/ask")
async def ws_ask(ws: WebSocket):
    await ws.accept()
    
    # Use a lock to prevent concurrent writes to the same websocket
    ws_lock = asyncio.Lock()

    async def safe_send(data):
        async with ws_lock:
            try:
                # Ensure data is JSON serializable
                await ws.send_json(data)
            except Exception as e:
                logger.error(f"Failed to send websocket message: {e}")

    try:
        data = await ws.receive_json()
    except Exception:
        await ws.close(code=1003)
        return

    query = data.get("query", "")
    mode = data.get("mode", "adaptive")
    use_search = data.get("use_search", True)
    preset_name = data.get("preset", "default")

    # Get personas based on preset
    personas = get_preset(preset_name)

    # Initialize MAGI with trace callback to stream events
    async def trace_callback(event):
        # Simply pass the engine event directly to the websocket
        # The engine now handles all formatting and node property access correctly
        await safe_send(event)

    # Pass the callback and personas to the engine
    engine = MAGI(personas=personas, trace_callback=trace_callback)
    
    try:
        await engine.ask(query, mode=mode, use_search=use_search)
    except WebSocketDisconnect:
        logger.info("Client disconnected")
    except Exception as e:
        logger.error(f"Engine error: {e}")
        try:
            await safe_send({"type": "error", "message": f"伺服器錯誤: {str(e)}"})
        except Exception:
            pass


def start_server(host: str = "0.0.0.0", port: int = 3001):
    """Start the NERV Command Center."""
    import uvicorn
    uvicorn.run(app, host=host, port=port)
