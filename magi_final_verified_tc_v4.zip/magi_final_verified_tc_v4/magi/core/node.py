from dataclasses import dataclass
import asyncio
import litellm
import time


@dataclass
class Persona:
    name: str
    description: str

    @property
    def system_prompt(self) -> str:
        return (
            f"You are {self.name}, one of the three MAGI decision nodes.\n"
            f"Your perspective: {self.description}\n"
            "Analyze the following query independently. Provide your honest assessment.\n"
            "IMPORTANT: You MUST provide your entire response in Traditional Chinese (繁體中文)."
        )


# Built-in personas
MELCHIOR = Persona("Melchior", "You think like an analytical scientist. Prioritize logic, evidence, and precision.")
BALTHASAR = Persona("Balthasar", "You think like an empathetic caregiver. Prioritize human impact, safety, and ethical considerations.")
CASPER = Persona("Casper", "You think like a pragmatic realist. Prioritize feasibility, efficiency, and practical outcomes.")


class MagiNode:
    def __init__(self, name: str, model: str, persona: Persona, timeout: float = 90.0):
        self.name = name
        self.model = model
        self.persona = persona
        self.timeout = timeout

    async def query(self, prompt: str) -> str:
        """Send a query to this node's LLM. Returns the response text or raises on failure."""
        messages = [
            {"role": "system", "content": self.persona.system_prompt},
            {"role": "user", "content": prompt},
        ]
        
        import random
        max_retries = 5
        base_delay = 10  # Longer delay for free models
        
        for attempt in range(max_retries):
            try:
                # Add jitter to avoid simultaneous retries hitting the same limit
                jitter = random.uniform(0.1, 2.0)
                if attempt > 0:
                    await asyncio.sleep(jitter)

                try:
                    response = await asyncio.wait_for(
                        litellm.acompletion(
                            model=self.model,
                            messages=messages,
                            num_retries=0, # Handle retries manually with better jitter
                        ),
                        timeout=self.timeout,
                    )
                except (litellm.BadRequestError, Exception) as e:
                    # If 400 error or specific failure, try merging system prompt into user prompt
                    err_str = str(e).lower()
                    if "system" in err_str or "400" in err_str or "provider" in err_str:
                        merged_prompt = f"{self.persona.system_prompt}\n\nUser Question: {prompt}"
                        response = await asyncio.wait_for(
                            litellm.acompletion(
                                model=self.model,
                                messages=[{"role": "user", "content": merged_prompt}],
                                num_retries=0,
                            ),
                            timeout=self.timeout,
                        )
                    else:
                        raise e
                
                msg = response.choices[0].message
                content = msg.content
                if not content and hasattr(msg, "reasoning_content") and msg.reasoning_content:
                    content = msg.reasoning_content
                if not content or not content.strip():
                    raise ValueError(f"Node {self.name} returned empty response")
                return content.strip()

            except (litellm.RateLimitError, Exception) as e:
                err_str = str(e).lower()
                is_rate_limit = "429" in err_str or "rate limit" in err_str
                
                if is_rate_limit and attempt < max_retries - 1:
                    # Exponential backoff with jitter
                    wait_time = (base_delay * (2 ** attempt)) + random.uniform(1, 5)
                    print(f"Node {self.name} hit rate limit. Retrying in {wait_time:.1f}s... (Attempt {attempt+1}/{max_retries})")
                    await asyncio.sleep(wait_time)
                    continue
                
                if attempt == max_retries - 1:
                    if "timeout" in err_str:
                        raise TimeoutError(f"Node {self.name} ({self.model}) timed out after {self.timeout}s")
                    if "401" in err_str or "auth" in err_str:
                        raise AuthenticationError(f"Node {self.name} authentication failed. Check API key.")
                    raise e
                
                # For other errors, small delay and retry
                await asyncio.sleep(3 + random.uniform(0, 2))
        
        raise Exception(f"Node {self.name} failed after {max_retries} attempts")


class AuthenticationError(Exception):
    pass
