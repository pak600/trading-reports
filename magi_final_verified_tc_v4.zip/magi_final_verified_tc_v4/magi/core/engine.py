from typing import Any, List, Dict, Optional, Callable
from pathlib import Path
import os
import asyncio
import time
import warnings

# Suppress annoying RuntimeWarnings and DeprecationWarnings
warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)

try:
    from duckduckgo_search import DDGS
except ImportError:
    DDGS = None

from magi.core.node import MagiNode, Persona, MELCHIOR, BALTHASAR, CASPER
from magi.core.decision import Decision
from magi.protocols.vote import vote
from magi.protocols.critique import critique
from magi.protocols.adaptive import adaptive


class MAGI:
    """
    MAGI — Disagreement OS for LLMs.
    
    The system uses three independent LLM nodes (Melchior, Balthasar, Casper)
    to deliberate on a query and produce a single, high-confidence decision.
    """

    def __init__(
        self,
        melchior: str = "openrouter/google/gemini-2.0-flash-lite-preview:free",
        balthasar: str = "openrouter/qwen/qwen-2.5-72b-instruct:free",
        casper: str = "openrouter/mistralai/mistral-7b-instruct:free",
        personas: tuple[Persona, Persona, Persona] | None = None,
        timeout: float = 120.0,
        trace_dir: str | None = None,
        trace_callback: Optional[Callable] = None,
    ):
        # Override defaults with environment variables if present
        melchior = os.environ.get("MAGI_MELCHIOR", melchior)
        balthasar = os.environ.get("MAGI_BALTHASAR", balthasar)
        casper = os.environ.get("MAGI_CASPER", casper)
        
        personas = personas or (MELCHIOR, BALTHASAR, CASPER)
        self.nodes = [
            MagiNode("melchior", melchior, personas[0], timeout=timeout),
            MagiNode("balthasar", balthasar, personas[1], timeout=timeout),
            MagiNode("casper", casper, personas[2], timeout=timeout),
        ]
        
        self.trace_callback = trace_callback
        # Set up tracing
        self.trace_dir = trace_dir or os.path.expanduser("~/.magi/traces")
        os.makedirs(self.trace_dir, exist_ok=True)

    async def search_web(self, query: str) -> str:
        """Perform a web search with a 5-second timeout protection (Python 3.10 compatible)."""
        if not DDGS:
            return ""
            
        try:
            # Python 3.10 compatible timeout
            await asyncio.sleep(0.5)
            
            def sync_search():
                with DDGS() as ddgs:
                    return list(ddgs.text(query, max_results=3))
            
            results = await asyncio.wait_for(asyncio.to_thread(sync_search), timeout=5.0)
            
            if not results:
                return ""
            
            context = "【最新聯網資訊 / Web Search Results】\n"
            for i, r in enumerate(results, 1):
                context += f"{i}. {r['title']}\n   內容: {r['body']}\n"
            return context
        except Exception as e:
            print(f"搜尋暫時不可用 (已跳過): {e}")
            return ""

    async def ask(
        self, 
        query: str, 
        mode: str = "adaptive",
        use_search: bool = True,
        **kwargs
    ) -> Decision:
        """
        Ask MAGI a question using a specific deliberation protocol.
        """
        # 1. Independent Analysis
        if self.trace_callback:
            await self.trace_callback({
                "type": "start", 
                "nodes": [{"name": n.name, "model": n.model} for n in self.nodes]
            })

        # If search is enabled, fetch latest info first
        if use_search:
            print(f"正在為詢問進行聯網搜尋: {query}...")
            search_context = await self.search_web(query)
            if search_context:
                query = f"{search_context}\n\n根據以上提供的聯網資訊，請針對以下問題進行審議：\n{query}"

        # Wrap node.query for tracing
        for node in self.nodes:
            # We must use a factory to avoid closure binding issues
            def make_wrapped_query(n):
                original_method = n.query
                async def wrapped(q):
                    if self.trace_callback:
                        await self.trace_callback({"type": "node_start", "node": n.name})
                    try:
                        res = await original_method(q)
                        if self.trace_callback:
                            await self.trace_callback({"type": "node_done", "node": n.name, "answer": res})
                        return res
                    except Exception as e:
                        if self.trace_callback:
                            await self.trace_callback({"type": "node_error", "node": n.name, "error": str(e)})
                        raise e
                return wrapped
            
            node.query = make_wrapped_query(node)

        # Execute deliberation based on mode
        # CRITICAL FIX: The correct order for fshiori/magi protocols is (query, nodes)
        try:
            if mode == "vote":
                decision = await vote(query, self.nodes, **kwargs)
            elif mode == "critique":
                decision = await critique(query, self.nodes, **kwargs)
            elif mode == "adaptive":
                decision = await adaptive(query, self.nodes, **kwargs)
            elif mode == "escalate":
                decision = await adaptive(query, self.nodes, threshold_high=0.1, **kwargs)
            else:
                raise ValueError(f"Unknown deliberation mode: {mode}")
        except Exception as e:
            if self.trace_callback:
                await self.trace_callback({"type": "error", "message": f"決策過程發生錯誤: {str(e)}"})
            raise e

        if self.trace_callback:
            await self.trace_callback({
                "type": "decision",
                "ruling": decision.ruling,
                "confidence": decision.confidence,
                "minority_report": decision.minority_report,
                "protocol_used": decision.protocol_used,
                "failed_nodes": decision.failed_nodes,
                "latency_ms": decision.latency_ms,
                "votes": decision.votes
            })
            
        return decision
